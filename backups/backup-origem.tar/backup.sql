-- MySQL dump 10.13  Distrib 8.4.5, for Linux (x86_64)
--
-- Host: localhost    Database: origem
-- ------------------------------------------------------
-- Server version	8.4.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Cliente`
--

DROP TABLE IF EXISTS `Cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Cliente` (
  `ID_Cliente` int NOT NULL,
  `Nome` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Telefone` varchar(20) DEFAULT NULL,
  `Cidade` varchar(50) DEFAULT NULL,
  `Sexo` varchar(50) DEFAULT NULL,
  `Idade` int DEFAULT NULL,
  `UF` char(2) DEFAULT NULL,
  PRIMARY KEY (`ID_Cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cliente`
--

LOCK TABLES `Cliente` WRITE;
/*!40000 ALTER TABLE `Cliente` DISABLE KEYS */;
INSERT INTO `Cliente` VALUES (1,'Ursula Oliveira','ursula.oliveira@email.com','(96201-5571)','Curitiba','F',34,'PR'),(2,'Fernanda Lima','fernanda.lima@email.com','(96350-7700)','Florianópolis','F',29,'SC'),(3,'Gustavo Oliveira','gustavo.oliveira@email.com','(92043-2246)','Porto Alegre','M',41,'RS'),(4,'Juliana Araújo','juliana.araújo@email.com','(91102-8230)','Curitiba','F',37,'PR'),(5,'Fernanda Araújo','fernanda.araújo@email.com','(96474-5084)','São Paulo','F',28,'SP'),(6,'Daniela Pereira','daniela.pereira@email.com','(99963-8627)','São Paulo','F',31,'SP'),(7,'Helena Oliveira','helena.oliveira@email.com','(94276-8981)','Porto Alegre','F',33,'RS'),(8,'Davi Silva','davi.silva@email.com','(93827-1011)','Porto Alegre','M',26,'RS'),(9,'Juliana Martins','juliana.martins@email.com','(97399-3306)','Curitiba','F',36,'PR'),(10,'Quésia Rocha','quésia.rocha@email.com','(92094-8002)','Curitiba','F',30,'PR'),(11,'Nicolas Lima','nicolas.lima@email.com','(94269-1158)','Curitiba','M',35,'PR'),(12,'Ana Gomes','ana.gomes@email.com','(93680-2139)','Curitiba','F',27,'PR'),(13,'Igor Ribeiro','igor.ribeiro@email.com','(97493-9403)','Florianópolis','M',38,'SC'),(14,'Nicolas Oliveira','nicolas.oliveira@email.com','(94149-1481)','Rio de Janeiro','M',42,'RJ'),(15,'Daniela Oliveira','daniela.oliveira@email.com','(93631-9456)','São Paulo','F',29,'SP'),(16,'Paulo Silva','paulo.silva@email.com','(92596-4563)','Belo Horizonte','M',43,'MG'),(17,'Emanuel Santos','emanuel.santos@email.com','(93150-4265)','Florianópolis','M',39,'SC'),(18,'Emanuel Martins','emanuel.martins@email.com','(96011-1515)','Rio de Janeiro','M',36,'RJ'),(19,'Carlos Lima','carlos.lima@email.com','(96241-7387)','Florianópolis','M',40,'SC'),(20,'Beatriz Santos','beatriz.santos@email.com','(94882-7725)','Curitiba','F',34,'PR'),(21,'Ursula Pereira','ursula.pereira@email.com','(97742-5448)','Florianópolis','F',31,'SC'),(22,'Daniela Gomes','daniela.gomes@email.com','(94965-1893)','Curitiba','F',28,'PR'),(23,'Helena Rocha','helena.rocha@email.com','(96974-4592)','Porto Alegre','F',32,'RS'),(24,'Fernanda Souza','fernanda.souza@email.com','(91824-2781)','Porto Alegre','F',29,'RS'),(25,'Emanuel Araújo','emanuel.araújo@email.com','(91301-3725)','Rio de Janeiro','M',37,'RJ'),(26,'Igor Silva','igor.silva@email.com','(91943-4028)','Belo Horizonte','M',34,'MG'),(27,'Karina Silva','karina.silva@email.com','(91534-3673)','Rio de Janeiro','F',30,'RJ'),(28,'Beatriz Costa','beatriz.costa@email.com','(93288-9491)','Florianópolis','F',33,'SC'),(29,'Fernanda Araújo','fernanda.araújo@email.com','(98909-5645)','Belo Horizonte','F',29,'MG'),(30,'Gustavo Silva','gustavo.silva@email.com','(92799-9317)','Belo Horizonte','M',38,'MG');
/*!40000 ALTER TABLE `Cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-08 15:20:59
